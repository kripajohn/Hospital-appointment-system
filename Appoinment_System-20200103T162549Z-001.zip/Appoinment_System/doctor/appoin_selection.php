<?php
  /* Author: Riya Joseph
  *
  */
    require "../config.php";
	include "../header.php";
	session_start();
	if($_SESSION["user_name"] && $_SESSION['dr_id']) 
	    {
		    echo"<h2> Welcome ".$_SESSION['user_name']."</h2>"; 
		    echo"<h4> Batch ".$_SESSION['dr_id']."</h4>"; 
	    }
		echo $user=$_SESSION['user_name'];
?>
		<center><a href="pop.php"><h5> click here to go back to</h5>
		<h3>Home </a></h3></center>
<?php 
	    $connection = new PDO($dsn, $username, $password, $options);
       //contains PDO connection script
	   
	try
	{
		 $id=$_POST['id'];
		 $name=$_POST['name'];
		 $age=$_POST['age'];
		 echo $date=$_POST['date'];
		 $gender=$_POST['gender'];
		 //$health=$_POST['p_health'];
		// $address=$_POST['address'];
		 $district=$_POST['district'];
		// $time=$_POST['time_alloted'];
		 		
		foreach($_POST['appoi'] as $key =>$val)
		{       
           echo $ntid = $key;
          echo  $status = $val;
		   
		   $sel = "Select * from appointmentform` where id='$key' and date_apmnt='$date'";
			$statement = $connection->prepare($sel);
            $statement->execute();
            $result = $statement->fetchAll();
			$sl="UPDATE appointmentform` SET status=? WHERE id=? ";
		
      $stmt= $connection->prepare($sel);
      $stmt->execute([ $status ,$key]);
	 // header("Location:doctor_dashboard.php");
			} 
		}
	
		
	catch(PDOException $e)
    {
        echo $stmt . "<br>" . $e->getMessage();
    }
	
//	include "footer.php";
?>