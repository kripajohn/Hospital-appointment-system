

<?php 
    /* Dashboard for Patients
	 * Features: 
	 * Authors: Kripa John
	 *
	 */
      //include "../header.php";
      require "../config.php";
	 
	 session_start();
	  if($_SESSION["user_name"] && $_SESSION["p_id"]) 
	              {
					 $_SESSION["user_name"]; 
					 $_SESSION["p_id"]; 
	               
	
	$connection = new PDO($dsn, $username, $password, $options);
?>

<!--sidebar start-->
<link href="css/style.css" rel="stylesheet" type="text/css">
<link href="../css/style.css" rel="stylesheet" type="text/css">
<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation" tabindex="5000" style="overflow: hidden; outline: none;">
         <center>  <?php 
                $user=$_SESSION["user_name"];
				$img = $connection->query("select gender from patient_reg where uname='$user'")->fetchColumn();
                if( $img=="Male"){?>
						   <img src="../img/download.jpg" width="100px" height="100px"class="prfl">
					  <?php } else{
						  ?>
						   <img src="../img/drf.png" class="prfl">
					  <?php } ?>
			<?php 
                if($_SESSION["uname"]) 
	               {
					   echo"<center><h4>" .$_SESSION["uname"]."</h4></center>"; 
					   
	               }
		    ?>
			</center>
			<ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="index.html">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <li class="sub-menu dcjq-parent-li">
                    <a href="doctors_list.php"  class="dcjq-parent">
                        
                        <span>Doctors Availability</span></a>
                    
                </li>
                
                <li class="sub-menu dcjq-parent-li">
                     
					<a href="appoinment_view.php"  class="dcjq-parent">
                        <span>Appoinment Form</span></a>
                </li>
               
                
                <li>
                    <a href="login.php">
                        
                        <span>Logout Page</span>
                    </a>
                </li>
            </ul>            </div>
        <!-- sidebar menu end-->
</aside>		
		
		
		<!--main content start-->
<section id="main-content">
	
	<div class="row">
	</div>
	<hr>
	
	<div class="row">
	<div class="col"><center>
	<p><a href="pedit_form.php"><img src="../img/edit.png"></a><br><br>Edit Profile</p>
	</center></div>
	
	
	</section>

<!--<marquee direction="right"> <img src="../img/santa.gif"></marquee>-->
				  <?php }
   // include "../footer.php";
	?>